import java.util.Scanner;

public class ejer2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int altura=sc.nextInt();
        for (int i = 1; i <=altura ; i++) {
            for (int j =1; j <=altura-1; j--) {
                System.out.println(" ");




            }
            

        }
        for (int i = 1; i <=altura ; i++) {
            for (int j = 0; j < ; j++) {
                
            }
            
            
        }


        }

}
