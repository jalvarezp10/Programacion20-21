import java.util.Scanner;

public class ejer1 {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int pares = 0;
        int impares=0;
        int pares2 = 0;
        int impares2=0;

        System.out.println("Introduce un numero");
        long num=sc.nextLong();
        System.out.println("Introduce otro");
        long num2=sc.nextLong();
        while(num>0){
            int digito1= (int) (num%10);


            if (digito1%2==0){

                pares=digito1;
            }else {
                impares=digito1;
            }




            num=num/10;




        }
        while(num2>0){
            int digito2= (int) (num%10);


            if (digito2%2==0){

                pares2=digito2;
            }else {
                impares2=digito2;
            }



            num=num/10;



        }
        System.out.println("Numero formado por numero pares: " +pares+pares2);
        System.out.println("Numero formado por numero impares: " +impares+impares2);


    }
}
